/* 
 * File:   main.cpp
 * Author: Bassam
 * Created on February 25, 2016, 2:30 PM
 */
//System Libraries
#include <iostream>
using namespace std;

//User libraries

//Global constants

int main(int argc, char** argv) {
     cout<<"problem 1"<< endl; //problem 1 in Gaddis chapter 2
     
     //declare vsriables 
    short int sum, a, b;
    
    //set values to variables
    a = 50;//assign value to a
    b = 100;//assign value to b
    
    //calculate the sum    
    sum = a+b;
    
    //Display the sum
    cout<<"the sum of "<<a<<"+"<<b<<"="<<sum<<endl;//Display results 

    return 0;
}

