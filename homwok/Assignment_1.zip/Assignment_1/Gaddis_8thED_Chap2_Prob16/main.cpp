/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Bassam
 *
 * Created on February 25, 2016, 2:35 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<< "problem 16"<<endl;//problem 16 in Gaddis chapter 2
    cout<<"   *"<<endl; //will show a star on the top center
    cout<<"  ***"<<endl;// 3 starts will appear 
    cout<<" *****"<<endl;// 5 stars will appear
    cout<<"*******"<<endl;// 7 stars will appear
    cout<<" *****"<<endl;// 5 stars will appear
    cout<<"  ***"<<endl;// 3 starts will appear 
    cout<<"   *"<<endl; //will show a star on the top center

    return 0;
}

